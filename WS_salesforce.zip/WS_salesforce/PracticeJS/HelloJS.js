    const name = "예진";
    const age = 30;
    const color = "파란색";

    if (age>=20) {
        console.log("성인입니다.");
    } else {
        console.log("미성년자입니다.");
    }

    function introduce(name,age) {
        return "안녕하세요. 제 이름은 " + name + "이고, 나이는 " + age + "살 입니다.";
    }

    console.log (introduce ("예진",30));