SalesforceInteractions.init({
  cookieDomain: ".milvus.co.kr"
}).then(() => {
    // UTM 소스 가져오기
    function getUTMSource() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get("utm_source") || "직접";
  }
    // 키워드 가져오기
    function getKeyword() {
    const urlParams = new URLSearchParams(window.location.search);
    // 네이버 광고 키워드
    if (urlParams.get("n_keyword")) {
      return decodeURIComponent(urlParams.get("n_keyword"));
    }
    // 구글 광고 키워드 (수동 태깅 시)
    if (urlParams.get("utm_term")) {
      return decodeURIComponent(urlParams.get("utm_term"));
    }
    return "없음";
  }
  const sitemapConfig = {
    // 글로벌 삽입
    global: {},
    pageTypes: [
      {
        name: "MainPage",
        isMatch: () => {
          try {
            const path = window.location?.pathname || "";
            console.log("DEBUG path:", path);
            return path === "/" || path === "/index.html";
          } catch (e) {
            console.warn("isMatch error:", e);
            return false;
          }
        },
        interaction: { name: "메인 페이지 방문" },
        // 문의하기 버튼 이벤트 수집
         listeners: [
          SalesforceInteractions.listener("click", ".btn-contact", () => {
            const utmSource = getUTMSource();
            const keyword = getKeyword();
            SalesforceInteractions.sendEvent({
              interaction: {
                name: `문의하기 버튼 클릭 - 유입: ${utmSource} 키워드: ${keyword}`
                },
              page: {
                url: window.location.href,
                title: document.title
              }
            });
          }),
          // Contact 탭 클릭 이벤트 수집
            SalesforceInteractions.listener("click", "a[href*='contact.html']:not(.btn-contact)", () => {
            const utmSource = getUTMSource();
            const keyword = getKeyword();
            SalesforceInteractions.sendEvent({
               interaction: {
               name: `Contact 메뉴 클릭 - 유입: ${utmSource} 키워드: ${keyword}`
                },
              page: {
                url: window.location.href,
                title: document.title
              }
            });
          }),
        ]
      },
      {
          name: "MigrationPage",
          isMatch: () => {
            const path = window.location?.pathname || "";
            console.log("DEBUG Migration path:", path);
            return path === "/page/solution/miGration.html"; 
          },
          interaction: { name: "Migration 페이지 방문" },
          listener: [
            // miGration 문의하기 수집
          SalesforceInteractions.listener("click", "a.form-btn", (event) => {
            event.preventDefault();
            const utmSource = getUTMSource();
            const keyword = getKeyword();
            const targetUrl = event.currentTarget.getAttribute("href");
            SalesforceInteractions.sendEvent({
              interaction: {
                name: `MiGration 문의하기 클릭 - 유입 : ${utmSource} - 키워드 : ${keyword}`
              },
              page: {
                url: window.location.href,
                title: document.title
              }
            }).then(() => {
                // 이벤트 전송 성공 후 새 탭 열기
                window.open(targetUrl, "_blank");
            }).catch(() => {
                // 실패해도 새 탭은 열기
                window.open(targetUrl, "_blank");
            });
            })
          ]
       }
    ],
    pageTypeDefault: {
      name: "Other",
      interaction: { name: "기타 페이지 방문" }
    }
  };
  SalesforceInteractions.initSitemap(sitemapConfig);
});