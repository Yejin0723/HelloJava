const hostName = window.location.hostname;

SalesforceInteractions.init({
  cookieDomain: ".milvus.co.kr"
}).then(() => {

  // =====================
  // 공통 유틸
  // =====================
  function getUTMSource() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get("utm_source") || "직접";
  }

  function getKeyword() {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get("n_keyword")) return decodeURIComponent(urlParams.get("n_keyword")); // 네이버
    if (urlParams.get("utm_term"))  return decodeURIComponent(urlParams.get("utm_term"));  // 구글(수동태깅)
    return "없음";
  }

  // =====================
  // 사이트맵 설정 (단 하나!)
  // =====================
  const sitemapConfig = {
    // 글로벌 삽입: 공통 페이지/속성 보강
    global: {
      onActionEvent: function (evt) {
        evt.page = evt.page || { url: location.href, title: document.title };

        const utmSource = getUTMSource();
        const keyword   = getKeyword();

        evt.attributes = evt.attributes || {};
        if (!evt.attributes.utm_source) evt.attributes.utm_source = utmSource;
        if (!evt.attributes.keyword)     evt.attributes.keyword    = keyword;

        return evt;
      }
    },

    pageTypes: [
      // =====================
      // 모든 페이지: 회사소개서(PDF) 다운로드 추적
      // =====================
      {
        name: "AllPagesDownload",
        isMatch: () => true,
        listeners: [
          SalesforceInteractions.listener(
            "click",
            [
              // 푸터 지정 클래스
              "footer a.link_company_download",
              // 다양한 경로 패턴 커버
              "a[href$='.pdf'][href*='/download/']",
              "a[href$='.pdf'][href^='./download/']",
              "a[href$='.pdf'][href^='/download/']",
              "a[href$='.pdf'][href^='download/']",
              // 쿼리스트링/대문자 확장자까지 완화 (선택 사항)
              "a[href*='.pdf?']",
              "a[href*='.PDF']"
            ].join(", "),
            (event) => {
              try {
                const utmSource = getUTMSource();
                const keyword   = getKeyword();

                // MCP로 전송 (요청 포맷)
                SalesforceInteractions.sendEvent({
                  interaction: {
                    name: `회사소개서다운로드 - 유입 ${utmSource} 키워드 : ${keyword}`
                  },
                  page: {
                    url: window.location.href,
                    title: document.title
                  }
                });
              } catch (e) {
                console.warn("[STK] sendEvent failed in listener:", e);
              }
            }
          )
        ]
      },

      // =====================
      // 메인 페이지
      // =====================
      {
        name: "MainPage",
        isMatch: () => {
          try {
            const path = window.location?.pathname || "";
            console.log("DEBUG path:", path);
            return path === "/" || path === "/index.html";
          } catch (e) {
            console.warn("isMatch error:", e);
            return false;
          }
        },
        interaction: { name: "메인 페이지 방문" },

        listeners: [
          // 문의하기 버튼
          SalesforceInteractions.listener("click", ".btn-contact", () => {
            const utmSource = getUTMSource();
            const keyword   = getKeyword();

            SalesforceInteractions.sendEvent({
              interaction: { name: `문의하기 버튼 클릭 - 유입: ${utmSource} 키워드: ${keyword}` },
              page: { url: window.location.href, title: document.title }
            });
          }),

          // Contact 메뉴(일반 링크)
          SalesforceInteractions.listener("click", "a[href*='contact.html']:not(.btn-contact)", () => {
            const utmSource = getUTMSource();
            const keyword   = getKeyword();

            SalesforceInteractions.sendEvent({
              interaction: { name: `Contact 메뉴 클릭 - 유입: ${utmSource} 키워드: ${keyword}` },
              page: { url: window.location.href, title: document.title }
            });
          }),

          // MiGration 문의하기 (새 탭 오픈 로직 안전 처리)
          SalesforceInteractions.listener("click", "a.form-btn", (event) => {
            const utmSource = getUTMSource();
            const keyword   = getKeyword();
            const targetUrl = event?.currentTarget?.getAttribute("href");

            const p = SalesforceInteractions.sendEvent({
              interaction: { name: `MiGration 문의하기 클릭 - 유입: ${utmSource} 키워드: ${keyword}` },
              page: { url: window.location.href, title: document.title }
            });

            // 전송 후 새 탭 열기 (Promise 유무에 상관없이 처리)
            if (p && typeof p.finally === "function") {
              p.finally(() => { if (targetUrl) window.open(targetUrl, "_blank"); });
            } else {
              if (targetUrl) window.open(targetUrl, "_blank");
            }
          })
        ]
      }
    ],

    pageTypeDefault: {
      name: "Other",
      interaction: { name: "기타 페이지 방문" }
    }
  };

  // =====================
  // 사이트맵 적용
  // =====================
  SalesforceInteractions.initSitemap(sitemapConfig);

  // =====================
  // (백업) 네이티브 캡처 리스너 + 동적 로드 대응
  //  - STK가 못 잡는 경우를 대비 (중복 방지 플래그 사용)
  // =====================
  (function setupDownloadBackup() {
    const SELECTORS = [
      "footer a.link_company_download",
      "a[href$='.pdf'][href*='/download/']",
      "a[href$='.pdf'][href^='./download/']",
      "a[href$='.pdf'][href^='/download/']",
      "a[href$='.pdf'][href^='download/']",
      "a[href*='.pdf?']",
      "a[href*='.PDF']"
    ];

    function bindNativeHandlers(root = document) {
      const nodes = root.querySelectorAll(SELECTORS.join(", "));
      nodes.forEach((el) => {
        if (el.dataset.siBound === "1") return; // 중복 바인딩 방지
        el.dataset.siBound = "1";

        el.addEventListener("click", (ev) => {
          try {
            const utmSource = getUTMSource();
            const keyword   = getKeyword();

            SalesforceInteractions.sendEvent({
              interaction: { name: `회사소개서다운로드 - 유입 ${utmSource} 키워드 : ${keyword}` },
              page: { url: window.location.href, title: document.title }
            });
          } catch (e) {
            console.warn("[native] sendEvent failed:", e);
          }
        }, { capture: true }); // 상위에서 가로채도 먼저 잡기
      });
    }

    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", () => bindNativeHandlers());
    } else {
      bindNativeHandlers();
    }

    const mo = new MutationObserver((muts) => {
      for (const m of muts) {
        m.addedNodes?.forEach((n) => {
          if (n.nodeType === 1) bindNativeHandlers(n);
        });
      }
    });
    mo.observe(document.documentElement, { childList: true, subtree: true });
  })();

});
