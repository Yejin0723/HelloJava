// UTM 소스 및 키워드 가져오기
const getSourceAndkeyword = () => {
  const urlParams = new URLSearchParams(window.location.search);

    // UTM 소스 수집
    if (urlParams.get("utm_source")) {
        source = urlParams.get("utm_source");
        sessionStorage.setItem("Source", source);
    } else if (urlParams.get("gad_source")) {
        source = "google";
        sessionStorage.setItem("Source", source);
    } else if (sessionStorage.getItem("Source")) {
        source = sessionStorage.getItem("Source");
    } else { 
        source = "직접";
    } 

    // 키워드 수집
    if (urlParams.get("n_keyword")) {
        keyword = urlParams.get("n_keyword");
        sessionStorage.setItem("Keyword", keyword);
    } else if (sessionStorage.getItem("Keyword")) {
        keyword = sessionStorage.getItem("Keyword");
    }
    // else if (urlParams.get("gbraid")) {
    //     keyword = urlParams.get("gbraid");
    // } 
    else {
        keyword = "없음";
    }

  return { source, keyword };
}  


SalesforceInteractions.init({
  cookieDomain: ".milvus.co.kr"
}).then(() => {

  // ============================
  // 사이트맵 구성
  // ============================
  const sitemapConfig = {
    global: {
    
      // 회사소개서 PDF 다운로드(상단/중앙/푸터 공통) 리스너
      listeners: [

        // 상단 회사소개서 수집  
        SalesforceInteractions.listener(
        "click",
        ".support a",
        () => {
            const { source, keyword } = getSourceAndkeyword();
            SalesforceInteractions.sendEvent({
            interaction: {
                name: `회사소개서 다운로드 - 유입 : ${source} - 키워드 : ${keyword}`
            }
            });
        }
        ),

        // 중앙 회사소개서서: class="btn btn_interview"
        SalesforceInteractions.listener(
        "click",
        "a.btn.btn_interview",
        () => {
            const { source, keyword } = getSourceAndkeyword();
            SalesforceInteractions.sendEvent({
            interaction: {
                name: `회사소개서 다운로드 - 유입 : ${source} - 키워드 : ${keyword}`
            }
            });
        }
        ),

        // 하단 회사소개서: class="link_company_download"
        SalesforceInteractions.listener(
        "click",
        "a.link_company_download",
        () => {
            const { source, keyword } = getSourceAndkeyword();
            SalesforceInteractions.sendEvent({
            interaction: {
                name: `회사소개서 다운로드 - 유입 : ${source} - 키워드 : ${keyword}`
            }
            });
        }
        ),

         // Contact 탭 클릭 이벤트 수집  
         SalesforceInteractions.listener(
            "click",
            "a[href*='/contact/contact.html']:not(.btn-contact)",
            () => {
            const { source, keyword } = getSourceAndkeyword();
            SalesforceInteractions.sendEvent({
                interaction: {
                name: `Contact 메뉴 클릭 - 유입 : ${source} - 키워드 : ${keyword}`
                }
            });
            }
        ),  
      ],
    },

    pageTypes: [
      {
        name: "MainPage",
        isMatch: () => {
          try {
            const path = window.location?.pathname || "";
            return path === "/" || path === "/index.html";
          } catch (e) {
            console.warn("isMatch error:", e);
            return false;
          }
        },
        interaction: { name: "메인 페이지 방문" },

        // 문의하기 버튼 이벤트 수집
        listeners: [
          SalesforceInteractions.listener("click", ".btn-contact", () => {
            const { source, keyword } = getSourceAndkeyword();
            SalesforceInteractions.sendEvent({
              interaction: {
                name: `문의하기 버튼 클릭 - 유입 : ${source} - 키워드 : ${keyword}`
              }
            });
          }),
        ]
      },
        
       // contact 페이지 방문 수집
      {
          name: "contactPage",
          isMatch: () => {
            const path = window.location?.pathname || "";
            return path === "/page/contact/contact.html";
          },
          interaction: { name: "contact 페이지 방문" }, 
      },  

      // miGration 페이지 방문 및 문의하기 수집  
      {
        name: "miGrationPage",
        isMatch: () => {
          const path = window.location?.pathname || "";
          return path === "/page/solution/miGration.html";
        },
        interaction: { name: "miGration 페이지 방문" },
        listeners: [
          SalesforceInteractions.listener("click", "a.form-btn", () => {
            const { source, keyword } = getSourceAndkeyword();
 
            SalesforceInteractions.sendEvent({
              interaction: {
                name: `miGration 문의하기 클릭 - 유입 : ${source} - 키워드 : ${keyword}`
              }
            })
          })
        ]
      }
    ],

    // ----------------------------
    // 그외 페이지
    // ----------------------------
    pageTypeDefault: {
      name: "Other",
      interaction: { name: "기타 페이지 방문" }
    }
  };

  SalesforceInteractions.initSitemap(sitemapConfig);
});