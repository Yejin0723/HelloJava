
// UTM 소스 및 키워드 가져오기
const getSourceAndkeyword = () => {
  const urlParams = new URLSearchParams(window.location.search);

    // UTM 소스 수집
    if (urlParams.get("utm_source")) {
        source = urlParams.get("utm_source");
        sessionStorage.setItem("Source", source);
    } else if (urlParams.get("gad_source")) {
        source = "google";
        sessionStorage.setItem("Source", source);
    } else if (sessionStorage.getItem("Source")) {
        source = sessionStorage.getItem("Source");
    } else { 
        source = "직접";
    } 

    // 키워드 수집
    if (urlParams.get("n_keyword")) {
        keyword = urlParams.get("n_keyword");
        sessionStorage.setItem("Keyword", keyword);
    } else if (sessionStorage.getItem("Keyword")) {
        keyword = sessionStorage.getItem("Keyword");
    }
    // else if (urlParams.get("gbraid")) {
    //     keyword = urlParams.get("gbraid");
    // } 
    else {
        keyword = "없음";
    }

  return { source, keyword };
}  

// ============================
// 사이트맵 구성
// ============================

SalesforceInteractions.init({
  cookieDomain: ".milvus.co.kr"
}).then(() => {

    const deviceWidth = window.innerWidth;
    //Const domain = window.location.hostname;
    const path = window.location.pathname;

    // 디버깅을 위한 로그 추가
    console.log("현재 화면 너비:", deviceWidth);
    console.log("현재 URL 경로:", path);
    console.log("모바일 조건 확인:", deviceWidth < 810 || path.includes("/mobile/"));


   // 모바일 부분 
  if (deviceWidth  < 801 || path.includes("/mobile/"))   {
      console.log("모바일")
      const mobileConfig = {
        global: {
            listeners: [
                // [모바일] 회사소개서 다운로드 수집
                SalesforceInteractions.listener(
                "click",
                "a.down-link",
                () => {
                    const { source, keyword } = getSourceAndkeyword();
                    SalesforceInteractions.sendEvent({
                        interaction: {
                            name: `[모바일] 회사소개서 다운로드 - 유입 : ${source} - 키워드 : ${keyword}`
                        }
                    });
                }
                ),
                 // [모바일] Contact 탭 클릭 이벤트 수집  
                    SalesforceInteractions.listener(
                        "click",
                        "a[href*='mobile/contact/contact.html']:not(.btn-contact-inner)",
                        () => {
                        const { source, keyword } = getSourceAndkeyword();
                        SalesforceInteractions.sendEvent({
                            interaction: {
                            name: `[모바일] Contact 메뉴 클릭 - 유입 : ${source} - 키워드 : ${keyword}`
                            }
                        });
                        }
                    ), 
                // [모바일] 메뉴 하단 문의하기 수집   
                    SalesforceInteractions.listener(
                        "click",
                        ".link inquiry",
                        () => {
                        const { source, keyword } = getSourceAndkeyword();
                        SalesforceInteractions.sendEvent({
                            interaction: {
                            name: `[모바일] 메뉴 문의하기 클릭 - 유입 : ${source} - 키워드 : ${keyword}`
                            }
                        });
                        }
                    ), 


            ],
        },
        pageTypes: [
            {
                name: "MainPage",
                isMatch: () => {
                     const path = window.location.pathname;
                    // '/mobile/index.html' 또는 '/'만 감지
                    return path === "/mobile/index.html" || path === "/";
                },
                interaction: { name: "[모바일] 메인 페이지 방문" },
                // [모바일] 문의하기 버튼 이벤트 수집
                    listeners: [
                    SalesforceInteractions.listener("click", ".btn-contact-inner", () => {
                    const { source, keyword } = getSourceAndkeyword();
                    SalesforceInteractions.sendEvent({
                    interaction: {
                    name: `[모바일] 문의하기 버튼 클릭 - 유입 : ${source} - 키워드 : ${keyword}`
              }
            });
          }),
        ]
            },
               // [모바일] contact 페이지 방문 수집
            {
                name: "contactPage",
                isMatch: () => {
                    const path = window.location?.pathname || "";
                    return path === "/mobile/company/contact.html";
                },
                interaction: { name: "[모바일] contact 페이지 방문" }, 
            },  
 
        ] 
      };

  SalesforceInteractions.initSitemap(mobileConfig);
} else { 

  // PC 부분
  const sitemapConfig = {
    global: {
    
      // 회사소개서 PDF 다운로드(상단/중앙/푸터 공통) 리스너
      listeners: [

        // 상단 회사소개서 수집  
        SalesforceInteractions.listener(
        "click",
        ".support a",
        () => {
            const { source, keyword } = getSourceAndkeyword();
            SalesforceInteractions.sendEvent({
            interaction: {
                name: `회사소개서 다운로드 - 유입 : ${source} - 키워드 : ${keyword}`
            }
            });
        }
        ),

        // 중앙: class="btn btn_interview"
        SalesforceInteractions.listener(
        "click",
        "a.btn.btn_interview",
        () => {
            const { source, keyword } = getSourceAndkeyword();
            SalesforceInteractions.sendEvent({
            interaction: {
                name: `회사소개서 다운로드 - 유입 : ${source} - 키워드 : ${keyword}`
            }
            });
        }
        ),

        // 하단: class="link_company_download"
        SalesforceInteractions.listener(
        "click",
        "a.link_company_download",
        () => {
            const { source, keyword } = getSourceAndkeyword();
            SalesforceInteractions.sendEvent({
            interaction: {
                name: `회사소개서 다운로드 - 유입 : ${source} - 키워드 : ${keyword}`
            }
            });
        }
        ),

         // Contact 탭 클릭 이벤트 수집  
         SalesforceInteractions.listener(
            "click",
            "a[href*='/contact/contact.html']:not(.btn-contact)",
            () => {
            const { source, keyword } = getSourceAndkeyword();
            SalesforceInteractions.sendEvent({
                interaction: {
                name: `Contact 메뉴 클릭 - 유입 : ${source} - 키워드 : ${keyword}`
                }
            });
            }
        ),  
      ],
    },

    pageTypes: [
      {
        name: "MainPage",
        isMatch: () => {
          try {
            const path = window.location?.pathname || "";
            return path === "/" || path === "/index.html";
          } catch (e) {
            console.warn("isMatch error:", e);
            return false;
          }
        },
        interaction: { name: "메인 페이지 방문" },

        // 문의하기 버튼 이벤트 수집
        listeners: [
          SalesforceInteractions.listener("click", ".btn-contact", () => {
            const { source, keyword } = getSourceAndkeyword();
            SalesforceInteractions.sendEvent({
              interaction: {
                name: `문의하기 버튼 클릭 - 유입 : ${source} - 키워드 : ${keyword}`
              }
            });
          }),
        ]
      },

       // contact 페이지 방문 수집
      {
          name: "contactPage",
          isMatch: () => {
            const path = window.location?.pathname || "";
            return path === "/page/contact/contact.html";
          },
          interaction: { name: "contact 페이지 방문" }, 
      },  

      // miGration 페이지 방문 및 문의하기 수집  
      {
        name: "miGrationPage",
        isMatch: () => {
          const path = window.location?.pathname || "";
          return path === "/page/solution/miGration.html";
        },
        interaction: { name: "miGration 페이지 방문" },
        listeners: [
          SalesforceInteractions.listener("click", "a.form-btn", () => {
            const { source, keyword } = getSourceAndkeyword();
 
            SalesforceInteractions.sendEvent({
              interaction: {
                name: `miGration 문의하기 클릭 - 유입 : ${source} - 키워드 : ${keyword}`
              }
            })
          })
        ]
      }
    ],

    // ----------------------------
    // 그외 페이지
    // ----------------------------
    pageTypeDefault: {
      name: "Other",
      interaction: { name: "기타 페이지 방문" }
    }
  };
   SalesforceInteractions.initSitemap(sitemapConfig);
}
 
});