SalesforceInteractions.init({
  cookieDomain: ".milvus.co.kr"
}).then(() => {

  // UTM 소스 가져오기
  function getUTMSource() {
    const urlParams = new URLSearchParams(window.location.search);
    
    if (urlParams.get("utm_source")) {
    return urlParams.get("utm_source");
    }

    if (urlParams.get("gad_source")) {
    return "google";
    }
    
    return "직접";
  }
  // 키워드 가져오기  
  function getKeyword() {
    const urlParams = new URLSearchParams(window.location.search);
    // 네이버 광고 키워드
    if (urlParams.get("n_keyword")) {
      return decodeURIComponent(urlParams.get("n_keyword"));
    }
    // // 구글 광고 키워드 (수동 태깅 시)
    // if (urlParams.get("utm_term")) {
    //   return decodeURIComponent(urlParams.get("utm_term"));
    // }
    return "없음";
  }

  // ============================
  // 사이트맵 구성
  // ============================
  const sitemapConfig = {
    // ----------------------------
    // GLOBAL: onActionEvent + 리스너
    // ----------------------------
    global: {
      // 모든 액션 공통 보강 (반드시 evt 또는 null 반환)
      onActionEvent: function (evt) {
        evt = evt || {};
        evt.page = evt.page || { url: location.href, title: document.title };

        const utm = getUTMSource();
        const kw  = getKeyword();

        const prevAttrs = evt.attributes || {};
        evt.attributes = {
          ...prevAttrs,
          utm_source: (prevAttrs.utm_source != null ? prevAttrs.utm_source : utm),
          keyword:    (prevAttrs.keyword    != null ? prevAttrs.keyword    : kw),
        };

        return evt; // ★ 중요: 반드시 반환!
      },

      // 회사소개서 PDF 다운로드(상단/중앙/푸터 공통) 리스너
      listeners: [
        SalesforceInteractions.listener(
          "click",
          // ./ 포함/불포함 모두 커버 (부분 매칭)
          "a[href*='download/250805_밀버스_회사소개서.pdf']",
          (event) => {
            try {
              event.preventDefault();

              const utmSource = getUTMSource();
              const keyword   = getKeyword();

              const a      = event.currentTarget;
              const href   = a.href; // 절대경로
              const target = a.getAttribute("target") || "_self";

              // 푸터에 기존 onclick이 있다면 안전 호출
              try {
                if (typeof window.conversionCheck03 === "function") {
                  window.conversionCheck03();
                }
              } catch (e) {
                console.warn("conversionCheck03 실행 중 오류:", e);
              }

              // 이벤트 전송 후 원래 링크 동작
              SalesforceInteractions.sendEvent({
                interaction: {
                  name: `회사소개서 다운로드 - 유입 : ${utmSource} - 키워드 : ${keyword}`
                },
                page: {
                  url: window.location.href,
                  title: document.title
                }
                // attributes는 onActionEvent에서 보강됨
              })
              .then(() => window.open(href, target))
              .catch(() => window.open(href, target));
            } catch (e) {
              console.warn("회사소개서 다운로드 리스너 오류:", e);
              // 예외 시에도 링크 동작 보장
              const a      = event.currentTarget;
              const href   = a.href;
              const target = a.getAttribute("target") || "_self";
              window.open(href, target);
            }
          }
        ),
      ]
    },

    pageTypes: [
      {
        name: "MainPage",
        isMatch: () => {
          try {
            const path = window.location?.pathname || "";
            return path === "/" || path === "/index.html";
          } catch (e) {
            console.warn("isMatch error:", e);
            return false;
          }
        },
        interaction: { name: "메인 페이지 방문" },

        // 문의하기 버튼 이벤트 수집
        listeners: [
          SalesforceInteractions.listener("click", ".btn-contact", () => {
            const utmSource = getUTMSource();
            const keyword   = getKeyword();
            SalesforceInteractions.sendEvent({
              interaction: {
                name: `문의하기 버튼 클릭 - 유입 : ${utmSource} - 키워드 : ${keyword}`
              },
              page: {
                url: window.location.href,
                title: document.title
              }
            });
          }),
        // Contact 탭 클릭 이벤트 수집  
          SalesforceInteractions.listener(
            "click",
            "a[href*='contact.html']:not(.btn-contact)",
            () => {
              const utmSource = getUTMSource();
              const keyword   = getKeyword();
              SalesforceInteractions.sendEvent({
                interaction: {
                  name: `Contact 메뉴 클릭 - 유입 : ${utmSource} - 키워드 : ${keyword}`
                },
                page: {
                  url: window.location.href,
                  title: document.title
                }
              });
            }
          ),
        ]
      },

      {
        name: "miGrationPage",
        isMatch: () => {
          const path = window.location?.pathname || "";
          return path === "/page/solution/miGration.html";
        },
        interaction: { name: "miGration 페이지 방문" },
        listeners: [
          SalesforceInteractions.listener("click", "a.form-btn", (event) => {
            event.preventDefault();
            const utmSource = getUTMSource();
            const keyword   = getKeyword();
            const targetUrl = event.currentTarget.getAttribute("href");

            SalesforceInteractions.sendEvent({
              interaction: {
                name: `miGration 문의하기 클릭 - 유입 : ${utmSource} - 키워드 : ${keyword}`
              },
              page: {
                url: window.location.href,
                title: document.title
              }
            })
            .then(() => window.open(targetUrl, "_blank"))
            .catch(() => window.open(targetUrl, "_blank"));
          })
        ]
      }
    ],

    // ----------------------------
    // 그외 페이지
    // ----------------------------
    pageTypeDefault: {
      name: "Other",
      interaction: { name: "기타 페이지 방문" }
    }
  };

  SalesforceInteractions.initSitemap(sitemapConfig);
});
