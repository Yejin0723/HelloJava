//초기 구성했을 때 ver1.
SalesforceInteractions.init({
  cookieDomain: window.location.hostname,
//   consents: [
//     {
//       provider: "Consent Provider",
//       purpose: "SalesforceInteractions.mcis.ConsentPurpose.Personalization",
//       status: SalesforceInteractions.ConsentStatus.OptIn, // OptOut → OptIn
//     },
//   ],
}).then(() => {
  const sitemapConfig = {
    global: { 
      listeners: [
        SalesforceInteractions.listener(
          "click",
          ".xans-layout-logotop.top_logo a", //메인 페이지 밀버스 글자 클릭
          () => {
            SalesforceInteractions.sendEvent({
              interaction: { name: "밀버스로고클릭" }
            });
          }
        )
      ]
    },

    // ← pageTypeDefault 대신 pageTypes에 기본 타입 하나 추가
    pageTypes: [
      {
        name: "default",
        isMatch: () => true,
        interaction: { name: "d" }
      },
    ]
  };

  SalesforceInteractions.initSitemap(sitemapConfig);
});
