SalesforceInteractions.init({
  cookieDomain: window.location.hostname,
  consents: [
    {
      provider: "Consent Provider",
      purpose: "SalesforceInteractions.mcis.ConsentPurpose.Personalization",
      status: SalesforceInteractions.ConsentStatus.OptIn, // OptOut → OptIn
    },
  ],
}).then(() => {
   SalesforceInteractions.log.level = "debug";

  const sitemapConfig = {
    global: { 
      // listeners: [
      //   SalesforceInteractions.listener(
      //     "click",
      //     ".prdList a", //제품 클릭
      //     () => {
      //       SalesforceInteractions.sendEvent({
      //         interaction: { name: "제품 상세페이지 클릭" }
      //       });
      //     }
      //   )
      // ]
    },

    // ← pageTypeDefault 대신 pageTypes에 기본 타입 하나 추가
pageTypes: [
  {
    name: "MainPage",
    isMatch: () => {
      return window.location.hostname === "milvus.cafe24.com" &&
             (window.location.pathname === "/" || window.location.pathname === "/index.html");
    },
    interaction: {mainPageVisit_interactionName: "메인 페이지 방문"}
      
     }
  
]  
};
  SalesforceInteractions.initSitemap(sitemapConfig);
});